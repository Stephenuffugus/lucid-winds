# PETAL WALK — ROOT MAZE (LABYRINTH) GAME SPEC
## For: Claude Code | Director Approved | April 1, 2026
## R&D: Ravensburger Labyrinth, aMAZE!ng, Tsuro, Reddit r/boardgames

## GAME SELECTOR ENTRY
{id:'rootmaze', n:'Root Maze', i:'🌀', r:'Shift maze rows to create paths. Collect all garden treasures!'}

## WHAT THIS IS
Shifting maze puzzle. Grid of path tiles. Push a spare tile into any row/column to shift the maze. Walk your piece along connected paths to collect treasures. Vs AI opponent.

## THE MECHANIC
- 5×5 grid of maze tiles (mobile-friendly, 7×7 as advanced)
- 3 tile types: Straight (│), Corner (└), T-junction (├)
- Each tile has paths on 1-4 sides connecting edges
- One spare tile in hand
- Per turn: (1) Insert spare into a row/column edge, (2) Move your piece along connected paths
- Tiles shift: inserting pushes all tiles in that row/column by 1, popping one out the other end
- Fixed tiles: some tiles are permanently fixed (can't be shifted) — anchors for the maze
- Goal: collect 6 treasures in order, then return to your starting corner

## BOARD LAYOUT (5×5)
- Alternate rows/columns are shiftable (rows 1,3 and cols 1,3 on 5×5)
- Corner tiles (0,0), (0,4), (4,0), (4,4) are fixed starting positions
- ~8 additional fixed tiles with treasures on them
- Remaining tiles are shiftable

## TILE RENDERING
Each tile is a 64×64px square showing path connections:
- Dark earth background
- Paths drawn as lighter "root" channels connecting edges
- Treasure icon centered on tiles that have treasures
- Player pieces (green seed = you, rose seed = AI) rendered on top

## SHIFT PREVIEW (Our #1 Differentiator)
When you tap a shift arrow:
1. Ghost tiles show where everything WILL move
2. The spare tile appears at the entry point (semi-transparent)
3. The tile that will pop out glows at the exit edge
4. Tap again to CONFIRM, or tap a different arrow to change
This prevents the #1 complaint: "I accidentally shifted the wrong row"

## SPARE TILE ROTATION
Before inserting, tap the spare tile to rotate it 90°. Shows all 4 orientations. The path connections change with rotation — choosing the right orientation is key strategy.

## AI DESIGN
- Easy: Shifts randomly, walks toward nearest visible treasure
- Medium: Evaluates which shift creates a path to its target, walks optimally
- Hard: Evaluates shifts for BOTH reaching its treasure AND blocking player's path

## TREASURE COLLECTION
- Each player has 6 treasure targets (dealt face-down, revealed one at a time)
- Current target shown prominently at top with glow
- When you walk onto the target tile: treasure collected! Next card flips.
- After all 6: must return to starting corner to win

## SOLO PUZZLE MODE (alternative)
- No AI opponent
- Collect ALL treasures in minimum shifts
- Star rating based on efficiency
- Puzzle mode = pure pathfinding optimization

## MOBILE UI
- 5×5 grid: tiles at 64px = 320px total
- Shift arrows: 44px tap targets on row/column edges
- Spare tile: displayed below board with rotate button
- Current target: shown large at top
- Player piece: green seed overlay on current tile
- AI piece: rose seed overlay

## HASH INTEGRATION
rootmaze: {treasure_collect:1, game_complete:3, efficient_win:2, default:0}
- 1 hash per treasure collected (6 per game)
- 3 on game complete
- 2 bonus for winning in under 15 turns

## RECORDS
rootmaze: {gamesPlayed, wins, treasuresCollected, bestTurnCount, puzzlesSolved, avgTurnsToWin}

## STRESS TEST
1. AI-vs-AI games: verify both players can collect all treasures (no impossible states)
2. Average game length: 15-30 turns (under 10 = too easy, over 40 = too slow)
3. Path connectivity: after any legal shift, at least 1 path of 3+ tiles exists
4. No deadlocks: player always has at least 1 legal shift that changes board state
