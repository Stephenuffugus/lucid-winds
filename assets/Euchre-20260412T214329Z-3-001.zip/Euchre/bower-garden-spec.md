# BOWER GARDEN — Spec
## Euchre (4-player trick-taking partnership card game)

**Game #21** | Hash Code: `bowergarden` | Strategy/Cards | 8-15 min

### Why "Bower Garden"
In Euchre, the Jacks (Bowers) are the most powerful cards. "Bower" also means a garden shelter/arbor. Perfect botanical double meaning.

### Rules
- 24-card deck (9-A in 4 suits), 4 players in 2 teams
- Trump calling: upcard turned, players order up or pass; round 2 names any suit
- Bower system: Right Bower (J of trump) is highest; Left Bower (J of same color) is second highest and BELONGS to trump suit
- 5 tricks per hand. Must follow suit (effective suit for left bower).
- Scoring: 3-4 tricks = 1pt, march (5 tricks) = 2pts, euchred = opponents get 2pts
- First to 10 wins

### AI Architecture (~250 lines)
- **Trump calling**: Hand strength evaluation counting bowers, trump count, off-aces. Threshold ≥4 to call.
- **Lead strategy**: Lead trump when strong (3+ trump), lead off-aces otherwise, lead low when weak
- **Follow strategy**: Play lowest winner, or dump lowest loser. Don't overtrump partner's winning trick.
- **Partner awareness**: Track whether partner is winning the current trick

### Competition
Euchre apps exist (Euchre 3D, Euchre Jogatina) but all riddled with ads, fake multiplayer, and bloat. Reddit: "I just want clean Euchre." Huge audience in Midwest US, Canada, military.

### Selector Entry
```javascript
{ id:'bowergarden', name:'Bower Garden', icon:'🃏', desc:'Euchre — trick-taking with bowers', cat:'strategy', diff:'medium', time:'8-15 min' }
```
