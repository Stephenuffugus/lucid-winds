# PETAL WALK — GARDEN SUMS (KAKURO) GAME SPEC
## For: Claude Code | Director Approved | April 1, 2026
## R&D: Kakuro.com, Conceptis, Sudoku.com, Simon Tatham, Reddit r/puzzles r/kakuro

## GAME SELECTOR ENTRY
{id:'kakuro', n:'Garden Sums', i:'➕', r:'Fill cells with 1-9 so each run adds to its clue. No repeats in a run!'}

## WHAT THIS IS
Number-logic puzzle. Grid of white cells and clue cells. Each "run" (horizontal or vertical group of white cells between clues/edges) must contain digits 1-9 that sum to the clue number. No digit repeats within a run. Zero AI needed. Pure deduction.

## CORE RULES
1. White cells contain digits 1-9
2. Clue cells show target sums (diagonal split: top-right = across, bottom-left = down)
3. Each horizontal/vertical run of white cells must sum to its clue
4. No digit can repeat within the same run
5. A digit CAN appear in both a horizontal and vertical run through the same cell

## EXAMPLE
Clue 6 across, 3 cells → must be {1,2,3} in some order (only combo summing to 6 with 3 unique digits)
Clue 16 across, 2 cells → must be {7,9} in some order (only combo of 2 unique digits summing to 16)

## WHAT MAKES IT ADDICTIVE
- The "cage math" — figuring out which combinations of digits are possible for a given sum+length
- Cross-referencing — a cell belongs to both a horizontal and vertical run, so constraints from both must agree
- The cascade — placing one number often eliminates possibilities in adjacent runs, triggering a chain of deductions
- The satisfaction of a clean fill with no conflicts

## GRID SIZES & DIFFICULTY
- 6×6: Beginner (2-3 min)
- 8×8: Easy (3-5 min)
- 10×10: Medium (5-10 min)
- 12×12: Hard (10-20 min)
- 14×14: Expert (15-30 min)

## SMART PENCIL SYSTEM (Our #1 Differentiator)
- Tap cell → number pad appears at bottom
- TAP a number → places as ANSWER (large, bold, centered, colored)
- LONG-PRESS a number → toggles PENCIL MARK (small, in 3×3 grid inside cell)
- No mode switching. No confusion. One gesture for answers, one for marks.
- Auto-elimination: confirmed answer removes that digit's pencil marks from same row/column runs
- Conflict detection: duplicate in run OR wrong sum → cell border turns red immediately
- This alone fixes the #1 complaint across ALL Kakuro apps

## CLUE CELL RENDERING
- Diagonal split (top-right triangle = across clue, bottom-left triangle = down clue)
- Dark background (#2C1810)
- Numbers in high-contrast white, 12px minimum
- Each triangle gets its own number, clearly separated by the diagonal line

## MOBILE UI LAYOUT (Pixel 9)
- Cell size: 36px for 10×10 (360px grid), scales up/down for other sizes
- Number pad: fixed at bottom of game panel (not screen), always visible
- Numbers 1-9 in a row, plus eraser and pencil toggle indicator

## PUZZLE GENERATION (Procedural)
Same approach as Conceptis/Simon Tatham:
1. Start with completed valid grid (all sums correct, no repeats)
2. Place clue cells to create runs
3. Remove answers, leaving only clues
4. Verify unique solution via constraint propagation + backtracking
5. Rate difficulty by solving techniques required

## HINT SYSTEM
3 hints per puzzle:
- Tap hint → reveals one cell's correct answer
- Auto-fills the cell and triggers pencil mark elimination
- Using hints caps star rating at 2 max

## STAR RATING
- ⭐: Solved (any time)
- ⭐⭐: Solved under target time OR with 0 errors
- ⭐⭐⭐: Solved under target time AND 0 errors AND 0 hints

## DAILY PUZZLE
- One curated puzzle per day, same for all players
- Streak tracking
- Difficulty rotates through the week

## HASH INTEGRATION
kakuro: {puzzle_solve:2, clean_solve:1, daily_solve:3, speed_bonus:1, default:0}
Target: 3-4 hashes per puzzle

## RECORDS
kakuro: {puzzlesSolved, totalStars, bestTimes per size, dailyStreak, cleanSolves, hintsUsed}

## STRESS TEST
1. All generated puzzles verified solvable with unique solution
2. Difficulty rating correlates with solve time (easy<3min, hard>10min)
3. No impossible combinations (e.g., sum 3 in 4 cells is impossible)
4. Generator success rate >70% per attempt
