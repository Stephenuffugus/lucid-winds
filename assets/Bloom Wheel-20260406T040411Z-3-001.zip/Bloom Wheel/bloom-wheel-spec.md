# BLOOM WHEEL — Spec
## Spinning Mandala Drawing Tool with Generative Beats

**Game #19** | Hash Code: `bloomwheel` | Creative Tool | Open-ended sessions

### The Gap
Nobody combines spinning canvas + radial symmetry + generative Web Audio beats + botanical aesthetic + mobile-first. Silk (weavesilk.com) does symmetry without music/rotation. Mandala apps are all ugly and static. This is a new format.

### Mechanics
- Touch to draw on rotating canvas with N-fold radial symmetry (4/8/12)
- Canvas rotates tied to BPM (1 revolution per 4 bars)
- Web Audio API: kick (sine 120→40Hz), hi-hat (filtered noise), ambient pad (detuned oscillators), pentatonic melody
- Color cycles through botanical palette based on distance from center + time
- Save mandala as PNG with watermark
- Hash: 1 per 60 seconds active drawing, 1 per save

### Selector Entry
```javascript
{ id:'bloomwheel', name:'Bloom Wheel', icon:'🌸', desc:'Draw botanical mandalas to a spinning beat', cat:'creative', diff:'easy', time:'open-ended' }
```
