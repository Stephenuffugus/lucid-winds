# PETAL WALK — GARDEN GATE (BACKGAMMON) GAME SPEC
## For: Claude Code (super-duper-enigma)
## From: Claude (Lead Dev) — Director Approved
## Date: April 1, 2026
## R&D Sources: GNUBG engine docs, XG Mobile, Backgammon NJ, Galaxy, Backgammon Live

---

## WHAT THIS IS

A new game for the Game tab game selector. Classic Backgammon — the 5,000-year-old dice + strategy racing game. Two players race to move all 15 checkers around the board and bear them off. Dice add randomness; strategy determines who wins consistently.

**Name in game:** "Garden Gate" — your pieces are seeds racing through garden paths to bloom.

**Design reference:** AI modeled on GNUBG's published evaluation heuristics. Animations modeled on Backgammon NJ. UI clarity modeled on Backgammon Galaxy. Onboarding modeled on Backgammon Live.

---

## GAME SELECTOR ENTRY

```javascript
{id:'backgammon', n:'Garden Gate', i:'🎲', r:'Roll dice, move seeds around the garden. Bear off all 15 first to win!'}
```

---

## WHY THIS GAME MATTERS

- 300M+ active players worldwide
- Massive in Turkey, Middle East, Greece, Eastern Europe — maps to Pi Network's global user base
- Dice element means beginners CAN beat experts (keeps it accessible)
- Deep enough strategy for thousands of hours of play
- Sessions run 5-15 minutes — excellent hash generation
- The "one more game" factor is legendary — backgammon is famously addictive
- Seniors LOVE it — direct hit on our primary brain-health demographic
- The doubling cube adds a poker-like risk/reward layer unique to backgammon

---

## BOARD LAYOUT

Classic backgammon board: 24 triangular points arranged in 4 quadrants of 6.

```
   13  14  15  16  17  18      19  20  21  22  23  24
   ▽   ▽   ▽   ▽   ▽   ▽  |B|  ▽   ▽   ▽   ▽   ▽   ▽
   |   |   |   |   |   |  |A|  |   |   |   |   |   |
   |   |   |   |   |   |  |R|  |   |   |   |   |   |
                           | |
   |   |   |   |   |   |  |B|  |   |   |   |   |   |
   |   |   |   |   |   |  |A|  |   |   |   |   |   |
   △   △   △   △   △   △  |R|  △   △   △   △   △   △
   12  11  10   9   8   7       6   5   4   3   2   1
```

- Points 1-6: Player's home board (bottom right)
- Points 7-12: Player's outer board (bottom left)
- Points 13-18: AI's outer board (top left)
- Points 19-24: AI's home board (top right)
- BAR: Center divider where hit checkers go
- Player moves: high numbers → low numbers (24→1 direction)
- AI moves: low numbers → high numbers (1→24 direction)

### Starting Position

```
Player (green seeds): 2 on point 24, 5 on point 13, 3 on point 8, 5 on point 6
AI (rose pieces):     2 on point 1, 5 on point 12, 3 on point 17, 5 on point 19
```

(This is the standard backgammon starting position, mirrored.)

---

## CORE RULES

### Dice Rolling
- Each turn: roll 2 six-sided dice
- Each die is a separate move (you make 2 moves per turn)
- You CAN use both dice on the same checker or split between two checkers
- **Doubles:** If you roll doubles (e.g., 4-4), you get 4 moves of that number instead of 2

### Moving Checkers
- Move a checker forward by the exact number on a die
- A checker can land on:
  - An empty point ✓
  - A point with your own checkers ✓ (stacking)
  - A point with exactly 1 opponent checker ✓ → **HIT** (opponent's checker goes to the bar)
  - A point with 2+ opponent checkers ✗ → **BLOCKED** (cannot land here)

### The Bar
- When a checker is hit, it goes to the bar (center)
- You MUST re-enter all bar checkers before making any other moves
- Re-entering: use a die to place the checker on the corresponding point in the opponent's home board (die shows 3 → enter on point 22 for player, or point 3 for AI)
- If all entry points are blocked, you lose your turn

### Bearing Off
- Once ALL 15 of your checkers are in your home board (points 1-6), you can start bearing off
- Use a die value to remove a checker from that point (roll 4 → remove from point 4)
- If no checker on the exact point, you MUST move a checker from a higher point
- If no checker on a higher point, you MAY bear off from the highest occupied point
- First player to bear off all 15 checkers wins

### Forced Moves
- You MUST use both dice if possible
- If you can only use one die, you must use the HIGHER value
- If you cannot move at all, you forfeit your turn

---

## DOUBLING CUBE (Optional — Medium/Hard modes)

The doubling cube is what separates casual backgammon from real backgammon. It adds a poker-like gambling element.

### How It Works
- Game starts at stakes of 1 point
- Before rolling, a player can DOUBLE the stakes (1→2→4→8→16→...)
- The opponent must either:
  - **ACCEPT:** Continue at double stakes
  - **DECLINE:** Forfeit the game at the current stakes
- After accepting, only the player who accepted can re-double
- Ownership of the cube alternates with each double

### For Petal Walk
- Easy mode: No doubling cube (simpler game)
- Medium mode: Doubling cube active (AI uses it strategically)
- Hard mode: Doubling cube + match play (first to N points)

### Gammon and Backgammon (Bonus wins)
- **Gammon:** If you bear off all checkers while opponent hasn't borne off ANY → worth 2× the cube value
- **Backgammon:** If you bear off all while opponent still has checkers on the bar or in your home board → worth 3× the cube value

---

## AI DESIGN — Based on GNUBG Heuristics

### The Science

GNUBG (GNU Backgammon) is open-source and world-champion caliber. Its evaluation function was published in academic papers. The key insight: you don't need a neural network to play strong backgammon. A well-tuned heuristic evaluation function plays at expert level.

### Evaluation Function (for each possible board state)

```javascript
function evaluatePosition(board, player) {
  var score = 0;
  
  // 1. PIP COUNT (race position) — lower is better
  var myPips = calculatePipCount(board, player);
  var oppPips = calculatePipCount(board, opponent);
  score += (oppPips - myPips) * 2;
  
  // 2. BLOT EXPOSURE — penalize unprotected checkers
  var blots = countBlots(board, player);
  score -= blots * 15;
  // Extra penalty for blots in opponent's home board
  var homeBlots = countBlotsInZone(board, player, 'oppHome');
  score -= homeBlots * 10;
  
  // 3. BLOCKING — reward consecutive occupied points (primes)
  var primeLen = longestPrime(board, player);
  score += primeLen * primeLen * 8; // exponential reward for longer primes
  // A 6-prime (all 6 points blocked) is devastating
  
  // 4. ANCHOR — reward points held in opponent's home board
  var anchors = countAnchorsInOppHome(board, player);
  score += anchors * 12;
  // High anchors (20-21 for player) are more valuable than low anchors
  
  // 5. HOME BOARD STRENGTH — reward built-up home board
  var homePoints = countMadePoints(board, player, 'home');
  score += homePoints * 10;
  
  // 6. CHECKER DISTRIBUTION — penalize too many checkers on one point
  var maxStack = largestStack(board, player);
  if (maxStack > 5) score -= (maxStack - 5) * 5;
  
  // 7. BEARING OFF PROGRESS
  var bornOff = 15 - countCheckersOnBoard(board, player);
  score += bornOff * 20;
  
  // 8. BAR — heavily penalize checkers on the bar
  var barCheckers = board.bar[player];
  score -= barCheckers * 40;
  
  return score;
}
```

### Move Selection

For each turn:
1. Generate all legal moves (considering both dice)
2. For each legal move, compute the resulting board state
3. Evaluate each resulting state with the function above
4. **Easy AI:** Pick randomly from the top 5 moves (plays okay but makes mistakes)
5. **Medium AI:** Pick the best move 70% of the time, random from top 3 otherwise
6. **Hard AI:** Always pick the best move + considers opponent's likely responses 1 ply deep

### Doubling Cube AI (Medium/Hard only)

```
Consider doubling if:
  - My pip count lead > 15%
  - I have a prime of 4+ AND opponent has checkers behind it
  - Opponent has 2+ checkers on the bar
  
Accept a double if:
  - My win probability > 25% (crude estimate from position eval)
  - I have a strong anchor in opponent's home board
  
Decline a double if:
  - Opponent has a 6-prime trapping my checkers
  - I'm behind in pip count by 30%+
  - I have no anchors and opponent is bearing off
```

### AI Response Timing
- Easy: 400-700ms
- Medium: 600-1000ms
- Hard: 800-1200ms

---

## BOTANICAL THEME

### Pieces
- **Player:** Green seeds (circular, with a subtle leaf vein pattern)
- **AI:** Rose buds (circular, with a subtle petal pattern)
- Both are simple circles with a botanical texture — they need to stack cleanly

### Board
- Points (triangles) alternate between two earth tones: warm soil brown (#5C4033) and mossy green (#3B5323)
- Board surface: dark rich wood (#2C1810) with subtle grain texture
- Bar: Vertical stone path texture
- Home board areas: slightly lighter background to distinguish
- Off-board bearing area: "bloom garden" where borne-off seeds become flowers

### Dice
- Warm ivory (#F5F0E1) with forest green pips (#4A7C35)
- 3D-look with subtle shadows
- Smooth roll animation

### Bearing Off Visual
When a seed is borne off, it "blooms" — briefly shows a small flower animation before settling into the off-board area. This is the satisfying visual reward for progress.

---

## MOBILE UI LAYOUT

Target: Pixel 9 (412×924 CSS viewport)

Backgammon boards are traditionally landscape, but mobile is portrait. Solution: rotate the board 90° so it's vertical.

```
┌────────────────────────────────────┐
│ 🎲 Garden Gate    You: 0  AI: 0   │
├────────────────────────────────────┤
│  AI BEARING OFF AREA               │
│  ┌──┬──┬──┬──┬──┬──┐ B ┌──┬──┬──┬──┬──┬──┐ │
│  │13│14│15│16│17│18│ A │19│20│21│22│23│24│ │
│  │▽ │▽ │▽ │▽ │▽ │▽ │ R │▽ │▽ │▽ │▽ │▽ │▽ │ │
│  │  │  │  │  │  │  │   │  │  │  │  │  │  │ │
│  │  │  │  │  │  │  │   │  │  │  │  │  │  │ │
│  │  │  │  │  │  │  │   │  │  │  │  │  │  │ │
│  │△ │△ │△ │△ │△ │△ │   │△ │△ │△ │△ │△ │△ │ │
│  │12│11│10│ 9│ 8│ 7│   │ 6│ 5│ 4│ 3│ 2│ 1│ │
│  └──┴──┴──┴──┴──┴──┘   └──┴──┴──┴──┴──┴──┘ │
│  YOUR BEARING OFF / HOME BOARD     │
├────────────────────────────────────┤
│  🎲 [3] [5]         [Double ×2]   │
│  Tap a seed, then tap destination  │
├────────────────────────────────────┤
│  ⚡ Hashes: 2                      │
└────────────────────────────────────┘
```

### Point Sizing
- Each point triangle: ~28px wide at base, ~120px tall
- 12 points per half = 336px + bar(20px) = ~356px — fits in 380px with margins
- Checkers: 24px diameter circles, stack vertically on points
- When >5 checkers on a point: show count badge instead of stacking all

### Interaction Flow
1. Player taps ROLL (or dice auto-roll on turn start)
2. Dice animate and land
3. Valid moves highlight (destination points glow green)
4. Player taps a checker → valid destinations for that checker highlight
5. Player taps destination → checker slides to new position
6. Repeat for second die (or combined if moving same checker twice)
7. After both dice used → AI turn begins

### Alternative: Drag to Move
Support both tap-tap and drag. Drag feels more natural on mobile (pick up checker, drag to point, release). But tap-tap is safer for accessibility.

---

## DICE ANIMATION

This is what Lord of the Board gets SO right. The dice roll must feel physical.

### Roll Animation (400ms total)
1. Dice start at center, slightly above board
2. Quick rotation animation (CSS transform: rotateX/Y cycling through faces)
3. "Bounce" — dice scale up slightly then settle
4. Final face appears with a brief glow
5. Subtle "clatter" sound (two quick wooden impacts)

```css
@keyframes diceRoll {
  0%   { transform: rotateX(0) rotateY(0) scale(1); }
  25%  { transform: rotateX(180deg) rotateY(90deg) scale(1.1); }
  50%  { transform: rotateX(360deg) rotateY(180deg) scale(0.95); }
  75%  { transform: rotateX(540deg) rotateY(270deg) scale(1.05); }
  100% { transform: rotateX(720deg) rotateY(360deg) scale(1); }
}
```

### Dice Display
After rolling, show the two dice values prominently between the board halves. If a die has been "used" (player moved that number), gray it out / cross it out. This helps players track which moves remain.

---

## MOVE VALIDATION

### Legal Move Generator

```javascript
function getLegalMoves(board, player, dice) {
  var moves = [];
  var d1 = dice[0], d2 = dice[1];
  
  // If checkers on bar, must enter first
  if (board.bar[player] > 0) {
    // Only moves that enter from bar
    var entryPoints = player === 'human' 
      ? [25 - d1, 25 - d2]  // enter on opponent's home board
      : [d1, d2];
    // Check if entry points are open (not blocked by 2+ opponent)
    // Generate only bar-entry moves
    return barEntryMoves(board, player, dice);
  }
  
  // For each die combination, for each checker, check if move is legal
  // Handle: single die moves, combined moves, doubles (4 moves)
  // A point is open if: empty, has your checkers, or has exactly 1 opponent
  
  // Must use both dice if possible
  // If only one can be used, must use the higher
  
  return allLegalMoveSequences(board, player, dice);
}
```

### Highlighting Valid Moves
When player selects a checker:
- All valid destination points glow with a green pulse
- Points where a hit would occur glow with a gold pulse (to call attention)
- Blocked points show no highlight

---

## SOUND DESIGN (Web Audio API)

| Event | Sound | Notes |
|-------|-------|-------|
| Dice roll | Wooden clatter — two quick impacts | The signature sound. Two bursts of filtered noise, slightly different pitch. |
| Checker move | Soft wooden slide + tap on landing | Sine click at 400Hz, 30ms |
| Checker hit | Sharper impact + opponent sound | Two tones: 300Hz thud + 600Hz snap |
| Bear off | Ascending chime + bloom sound | Happy, rewarding |
| Doubles rolled | Extra flourish after dice | Brief arpeggio — doubles are exciting |
| Invalid move attempt | Dull thud | Low, brief |
| AI doubling | Dramatic low tone | Tension builder |
| Win | Full celebratory arpeggio | Garden blooming sounds |
| Lose | Gentle descending | Never harsh |

---

## HASH INTEGRATION

```javascript
backgammon: {milestone:1, game_complete:3, gammon_bonus:2, backgammon_bonus:3, default:0}
```

| Event | Trigger | Hashes |
|-------|---------|--------|
| milestone | Every 5 checkers borne off | 1 each (at 5, 10, 15 = 3 milestones) |
| game_complete | Game ends | 3 × _dm |
| gammon_bonus | Win by gammon (opponent bore off 0) | 2 |
| backgammon_bonus | Win by backgammon (opponent on bar/your home) | 3 |

Difficulty multiplier: Easy=1.0, Medium=1.5, Hard=2.0

Target: 6-9 hashes per game, 8-15 minute sessions.

---

## RECORDS

```javascript
backgammon: {
  gamesPlayed: 0,
  wins: 0,
  losses: 0,
  gammons: 0,
  backgammons: 0,
  doublesRolled: 0,
  checkersHit: 0,
  totalPointsScored: 0,
  longestWinStreak: 0,
  bestWinEasy: null,
  bestWinMedium: null,
  bestWinHard: null,
  totalBearOffs: 0
}
```

---

## ONBOARDING (First Play Only)

5 interactive panels:

**Panel 1:** "Move your 15 seeds around the garden path. Roll dice to see how far you can go."
**Panel 2:** "Each die is a separate move. You can move one seed twice or two seeds once each."
**Panel 3:** "Land on a lone opponent seed to send it to the bar! They must re-enter before moving."
**Panel 4:** "Get all your seeds to your home garden (points 1-6), then bear them off to win!"
**Panel 5:** "Stack 2+ seeds on a point to protect them. A single seed is vulnerable!"

Skip button always visible. Never shows again.

---

## STRESS TEST REQUIREMENTS

The stress test must verify:
1. **AI vs AI balance:** Neither first-player nor second-player should win >55%
2. **Game length:** Average 40-80 total moves (both players combined). Under 30 = too fast. Over 100 = too slow.
3. **Dice fairness:** Over 5000 games, each die face should appear ~16.67% (±1.5%)
4. **Gammon rate:** 15-25% of games should end in gammon (if under 10%, AI isn't aggressive enough; over 35%, games feel punishing)
5. **Bar usage:** Average checkers-hit-per-game should be 4-8 (under 2 = too passive, over 12 = too chaotic)
6. **Bearing off distribution:** Both players should start bearing off in the same turn range (±3 turns)
7. **AI strength by level:** Easy AI should lose to Medium >70%. Medium should lose to Hard >65%.

---

## WHAT NOT TO DO

- Do NOT use position:fixed for any game elements
- Do NOT rewrite switchTab
- Do NOT modify any economy values
- Do NOT skip the dice animation — it IS the game feel
- Do NOT make the AI play instantly
- Do NOT allow illegal moves (the forced-move rules are complex — validate everything)
- Do NOT forget the "must use both dice" rule — this catches many implementations
- Do NOT make checkers smaller than 22px — need to be tappable
- Do NOT skip the bar re-entry rule — many clones get this wrong
- Do NOT show the doubling cube on Easy mode

---

## TESTING CHECKLIST

1. [ ] Board renders with 24 points, bar, and bearing-off areas
2. [ ] Starting position is correct (2-5-3-5 distribution)
3. [ ] Dice roll animation plays smoothly
4. [ ] Each die value can be used independently
5. [ ] Doubles give 4 moves
6. [ ] Cannot land on points with 2+ opponent checkers
7. [ ] Hitting a blot sends it to the bar
8. [ ] Bar checkers must re-enter before any other move
9. [ ] Bar re-entry blocked correctly when opponent holds points
10. [ ] Bearing off only allowed when all 15 in home board
11. [ ] Bear off rules: exact point, higher point, or highest occupied
12. [ ] Forced move rule: must use both dice, prefer higher if only one possible
13. [ ] Move highlighting shows valid destinations
14. [ ] Checker movement animation slides smoothly
15. [ ] AI plays reasonable moves at all 3 difficulty levels
16. [ ] Doubling cube works on Medium/Hard
17. [ ] Gammon and backgammon detection correct
18. [ ] Win/loss properly detected and displayed
19. [ ] Bearing off bloom animation plays
20. [ ] Dice sound is satisfying wooden clatter
21. [ ] Onboarding shows on first play only
22. [ ] Hash events fire correctly
23. [ ] Records save and persist
24. [ ] All moves validated — no illegal state possible
25. [ ] Plays correctly on Pixel 9 in Chrome incognito

---

*Spec complete. Prototype and stress test to follow.*
