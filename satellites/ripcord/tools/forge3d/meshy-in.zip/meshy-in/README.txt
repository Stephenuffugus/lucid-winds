RIPCORD -> MESHY, the whole job on one page
============================================

These 44 images are the 22 cores and 22 blades, cut from your sheets,
one part per image, transparent background - exactly what Meshy's
Image to 3D wants. The hardware (assists, ratchets, bits, weights) is
NOT here on purpose: those are already built procedurally and a
ratchet's teeth have to be countable, which a generator can't promise.

DO A PILOT OF 4 FIRST. Don't spend 44 credits before the import lane
has eaten real Meshy output once. Good pilot set:
    core-bell.png      (a real object, tests sculpt quality)
    core-moth.png      (fine detail, tests what survives)
    blade-cleaver.png  (deep spurs, tests silhouette)
    blade-orbit.png    (smooth ring, tests the boring case)
Send those 4 back, I fit them to the mount and check triangles and
dimensions. If they pass, run the other 40 the same way.

FOR EACH IMAGE:
1. Meshy -> Image to 3D -> upload the PNG. Default settings are fine.
   If it asks for a polycount, medium (10-30k) - I decimate anyway.
2. NAME THE GENERATION EXACTLY LIKE THE FILE, e.g. "blade-cleaver".
   The name is how the pipeline knows which part it is. The ids look
   odd on purpose (millst IS Cairn, ballast IS Trim, vise IS Pincer) -
   don't fix them, the game speaks in ids.
3. Export / download as GLB.

WHEN DONE: zip all the GLBs (any folder layout, names intact) and get
it to me the same way as tonight's zip. I take it from there - mount
machining, triangle budget, validation, renders all happen in Blender
here. You never need to be present for rendering.
